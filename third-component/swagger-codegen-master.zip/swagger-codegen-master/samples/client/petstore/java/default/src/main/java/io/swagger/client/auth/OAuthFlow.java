package io.swagger.client.auth;

public enum OAuthFlow {
    accessCode, implicit, password, application
}