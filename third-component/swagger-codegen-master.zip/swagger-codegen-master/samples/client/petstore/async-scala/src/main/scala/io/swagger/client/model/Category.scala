package io.swagger.client.model

import org.joda.time.DateTime


case class Category (
  id: Long,
  name: String
  
)
