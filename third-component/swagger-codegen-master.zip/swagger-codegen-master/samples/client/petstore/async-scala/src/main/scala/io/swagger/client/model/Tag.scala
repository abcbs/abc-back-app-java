package io.swagger.client.model

import org.joda.time.DateTime


case class Tag (
  id: Long,
  name: String
  
)
