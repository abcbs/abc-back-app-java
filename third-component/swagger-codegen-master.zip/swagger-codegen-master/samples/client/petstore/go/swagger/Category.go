package swagger

import (
)

type Category struct {
    Id  int64  `json:"id,omitempty"`
    Name  string  `json:"name,omitempty"`
    
}
