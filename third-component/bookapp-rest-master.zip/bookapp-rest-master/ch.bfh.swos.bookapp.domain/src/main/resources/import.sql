insert into author(id, firstname, lastname) values (1, 'J.R.R', 'Tolkien');
insert into author(id, firstname, lastname) values (2, 'Stephen', 'King');

insert into book(id, title, releasedate, author_id) values (1, 'Lord of the Rings - Fellowship of the Ring', '2013-04-01', 1);
insert into book(id, title, releasedate, author_id) values (2, 'Lord of the Rings - Return of the King', '2011-02-15', 1);