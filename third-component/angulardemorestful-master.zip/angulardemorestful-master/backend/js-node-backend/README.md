
# Node.js backend

## Installation

Install [node.js](http://nodejs.org/download/).

Run `npm install`. This will install [express](https://npmjs.org/package/express) to the folder `node_modules`.

## Usage

Run `node app.js` from this folder.

Try the following URLs:

```
http://localhost:8080/ngdemo/web/users
http://localhost:8080/ngdemo/web/dummy
http://localhost:8080/ngdemo/web/users/3
```

TODO: 

- Write curl commands for PUT and DELETE...
- tests
- cleanup
- ...
