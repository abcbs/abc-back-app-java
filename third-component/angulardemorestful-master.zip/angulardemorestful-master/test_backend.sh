#!/bin/bash

curl -i -X GET -H 'Content-Type: application/json' \
	http://localhost:8080/ngdemo/web/dummy
