'use strict';

describe('Controller: ngdemoApp.controllers', function () {

  /* karma test runner fails if it can't find a test... */
  it('should always be true', function () {
    expect(true).toBe(true);
  });
});