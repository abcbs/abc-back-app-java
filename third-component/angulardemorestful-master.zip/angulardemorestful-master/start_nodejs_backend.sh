#!/bin/bash

cd backend/js-node-backend/
node app.js
