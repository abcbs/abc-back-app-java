// JavaScript Document
var app = angular.module("myApp",[]);
//回到顶部
app.directive('tabs', function($http) {
    return {
        restrict : 'EA',
        replace : true,
        transclude : true,
        template :'<ul class="category-ul" ng-transclude></ul>',
        controller: [ "$scope", function($scope) {
        	var panes = [];
            this.gotOpened = function(selectedPane) {
                angular.forEach(panes, function(pane) {
                    if (selectedPane != pane) {
                    	pane.selected = false;
                    }else{
                    	$scope.page=1;
                    	$scope.finished=true;
                    	pane.selected = true;
                    	$(".inner").scrollTop(0);
                    	var billId=localStorage.getItem("billId");
                    	if(billId==null){
                    		billId="";
                    	}
                    	if($("#billId").val()!=""){
                    		var billId=$("#billId").val();
                    	}
                		var data={'page':1,'pageSize':'10','keyWords':'','sortType':'showSeq','categoryId':pane.id,'billId':billId};
                		var ctx=$("#ctx").val();
                		var url=ctx+"/h5/h5OrderPo?r="+Math.random();
                		$http({method:"POST",params:data,url:url}).success(function(data) {
                			$scope.lists=data.objectzJson.dishesList;
                			$scope.allMoney=data.objectzJson.oriCost;
                			for(var i=0;i<data.objectzJson.dishesList.length;i++){
                				if(data.objectzJson.dishesList[i].dishesCount!='0'){
                					$scope.lists[i].disheupanddown=true;
                				}else{
                					data.objectzJson.dishesList[i].dishesCount="";
                				}
                			}
                		});
                    }
                });
            }
            this.addPane = function(pane) {
            	panes.push(pane);
            }
       }]
    }
});
app.directive('pane', function($http) {
    return {
        restrict : 'EA',
        replace : true,
        transclude : true,
        require : '^?tabs',
        scope : {
            title : '=tabsTitle',
            count:'=tabsCount',
            id:'=tabsId',
            d:'=tabsDown'
        },
        template :'<li ng-class="{active:selected}" ng-click="categoryFun(id)">'
    		+'<a href="#">{{title}}<span class="m-badge" ng-show={{d}}>{{count}}</span></a></li>',
        link : function(scope, element, attrs, tabsController) {
        	tabsController.addPane(scope);
        	scope.categoryFun = function(id) {
        		$("#categoryId").val(id);
        		tabsController.gotOpened(scope);
        	}
        }
    }
});
app.controller("myCtrl",function($scope,$http){
	ajaxPost($scope,$http,'',1);
	$scope.allTotal=0;//总数量
	$scope.allMoney=0;//总金额
	$scope.xdVar=true;//下单 控制按钮是否为disabled变量
	$scope.page=1;
	$scope.yVar=false;
	$scope.nVar=true;
	$scope.totalnum=false;
	$scope.showmoney=false;
	//+号点击方法
	$scope.plusFun=function(target,id,name){
		$scope.yVar=true;
		$scope.nVar=false;
		if($scope.lists[id].dishesCount==""){
			$scope.lists[id].dishesCount='0';
		}
		$scope.lists[id].disheupanddown=true;
		$scope.lists[id].dishesCount=parseInt($scope.lists[id].dishesCount)+1;
		$scope.xdVar=false;
		$scope.totalnum=true;
		$scope.showmoney=true;
		$scope.allTotal++;
		for(var i=0;i<$scope.categorys.length;i++){
			if($scope.categorys[i].categoryName==name){
				$scope.categorys[i].upanddown=true;
				$(".category-ul li").eq(i).find(".m-badge").removeClass("ng-hide");
				if($scope.categorys[i].categoryCount==""){
					$scope.categorys[i].categoryCount=0;
				}
				$scope.categorys[i].categoryCount=parseInt($scope.categorys[i].categoryCount)+1;
			}
		}
		$scope.sumAll(id);
		plusAjaxPost($scope.lists[id].dishesId,$scope.allMoney);
	};
	//-号点击方法
	$scope.minusFun=function(target,id,name){
		$scope.lists[id].dishesCount=parseInt($scope.lists[id].dishesCount)-1;
		if($scope.lists[id].dishesCount==0){
			$scope.lists[id].dishesCount="";
			$scope.lists[id].disheupanddown=false;
		}
		$scope.allTotal--;
		for(var i=0;i<$scope.categorys.length;i++){
			if($scope.categorys[i].categoryName==name){
				$scope.categorys[i].categoryCount=parseInt($scope.categorys[i].categoryCount)-1;
				if($scope.categorys[i].categoryCount==0){
					$scope.categorys[i].upanddown=false;
					$(".category-ul li").eq(i).find(".m-badge").addClass("ng-hide");
				}
			}
		}
		$scope.sumAllm(id);
		if($scope.allTotal==0){
			$scope.yVar=false;
			$scope.nVar=true;
			$scope.totalnum=false;
			$scope.showmoney=false;
		}
		minsAjaxPost($scope.lists[id].dishesId,$scope.allMoney);
	};
	//计算总金额方法
	$scope.sumAll=function(id){
		var result = 0;
		if($scope.allMoney==""){
			$scope.allMoney=0;
		}
		result=$scope.lists[id].dishesPrice*1;
		$scope.allMoney=(parseFloat($scope.allMoney)+parseFloat(result)).toFixed(2);
	};
	//计算总金额方法
	$scope.sumAllm=function(id){
		var result = 0;
		if($scope.allMoney==""){
			$scope.allMoney=0;
		}
		result=$scope.lists[id].dishesPrice*1;
		$scope.allMoney=(parseFloat($scope.allMoney)-parseFloat(result)).toFixed(2);
	};
	//删除按钮方法
	$scope.delAllData=function(){
		$scope.allTotal=0;
		$scope.allMoney=0;
		$scope.xdVar=true;
		$scope.yVar=false;
		$scope.nVar=true;
		$scope.totalnum=false;
		$scope.showmoney=false;
		$(".category-ul li").each(function(index){
			$scope.categorys[index].categoryCount="";
			$scope.categorys[index].upanddown=false;
			$(this).find(".m-badge").addClass("ng-hide");
		});
		$(".listgroup li").each(function(index){
			$scope.lists[index].disheupanddown=false;
			$scope.lists[index].dishesCount="";
		});
		var ctx=$("#ctx").val();
		var url=ctx+"/h5/deleteBillItem";
		var billId=$("#billId").val();
		var data={'billId':billId};
		$http({method:"POST",params:data,url:url}).success(function(data) {
			$("#billId").val("");
		});
		localStorage.clear();
	}
	//下单方法
	$scope.xiadanFun=function(){
		var billId=localStorage.getItem("billId");
		if(billId==null){
			billId="";
		}
		if($("#billId").val()!=""){
			var billId=$("#billId").val();
		}
		xdAjaxPost($http,$scope,billId);
	};
	$scope.orderlistsFun=function(){
		var ctx=$("#ctx").val();
		window.location.href=ctx+"/h5/orderListPage";
	}
	//注销
	$scope.logout=function(){
		localStorage.clear();
		var ctx=$("#ctx").val();
		window.location.href=ctx+"/h5/logout";
	}
	//下拉刷新
	var finished=true;
	var page=1;
	$(".inner").scroll(function(){
		var height=$(this).height();//可见高度
		var conHeight=$(this).get(0).scrollHeight;
		var scrollHieght=$(this).scrollTop();
		if(finished&&scrollHieght==conHeight-height){
			finished=false;
			page=page+1;
			$(".load").remove();
			$(".inner").append("<div class='load'>加载中...</div>");
			var id=$("#categoryId").val();
			var data={'page':page,'pageSize':'10','keyWords':'','sortType':'showSeq','categoryId':id,'billId':""};
			var ctx=$("#ctx").val();
			var url=ctx+"/h5/h5OrderPo";
			$.ajax({
				url:url,
				type:'post',
				data:data,
				success:function(data){
					if(data.statusCode=="1007"){
						$(".load").html("暂时无数据");
					}
					if(data.statusCode=="0000"){
						finished=true;
						$(".load").remove();
						for(var i=0;i<data.objectzJson.dishesList.length;i++){
							var liElement='<li class="list-item">'
								+'<div class="wrap"><div class="list-img"><img src=${ctx}{{x.dishesPic[0].picUrl}} width="100" height="80" /></div>'
								+'<div class="list-content"><p class="list-title">'+data.objectzJson.dishesList[i].dishesName+'</p>'
								+'<p class="price"><span class="price-color">￥'+data.objectzJson.dishesList[i].dishesPrice+'</span>/'+data.objectzJson.dishesList[i].unitName+'</p>'
								+'<div class="m-btn-wrap"><div class="item-add">'
								+'<span class="item-cbtn minus" ng-click="minusFun($event.target,$index,'+data.objectzJson.dishesList[i].categoryName+')" ng-show="x.disheupanddown"><i class="fa fa-minus-circle fa-2x"></i></span>'
								+'<span class="item-count">'+data.objectzJson.dishesList[i].dishesCount+'</span>'
								+'<span class="item-cbtn plus" ng-click="plusFun($event.target,$index,'+data.objectzJson.dishesList[i].categoryName+')"><i class="fa fa-plus-circle fa-2x"></i></span>'
								+'</div></div></div></div></li>';
							$('.listgroup').append($compile(liElement)(scope));
							var template = angular.element(liElement);
							var mobileDialogElement = $compile(template)($scope);
							angular.element(document.body).append(mobileDialogElement);
						}
					}
				},
				error:function(){
					alert("请求错误");
				}
			});
		}
	});
});

/*点击+号 ajax*/
function plusAjaxPost(dishesId,billMoney){
	var billId=localStorage.getItem("billId");
	if(billId==null){
		billId="";
	}
	if($("#billId").val()!=""){
		var billId=$("#billId").val();
	}
	var data={'billId':billId,'tabId':'','dishesId':dishesId,'dishesCount':'1','billMoney':billMoney};
	var ctx=$("#ctx").val();
	var url=ctx+"/h5/createBill";
	$.ajax({
		url:url,
		type:"post",
		data:data,
		beforeSend:function(){
			
		},
		success:function(data){
			localStorage.setItem("billId",data.objectzJson.billId);
		},
		error:function(){
			
		},
		complete:function(){
			
		}
	});
}
/*-号ajaxpost */
function minsAjaxPost(dishesId,billMoney){
	var billId=localStorage.getItem("billId");
	if(billId==null){
		billId="";
	}
	if($("#billId").val()!=""){
		var billId=$("#billId").val();
	}
	var data={'billId':billId,'dishesId':dishesId,'dishesCount':'1','billMoney':billMoney};
	var ctx=$("#ctx").val();
	var url=ctx+"/h5/reduceBill";
	$.ajax({
		url:url,
		type:"post",
		data:data,
		beforeSend:function(){
			
		},
		success:function(data){
			localStorage.setItem("billId",data.objectzJson.billId);
		},
		error:function(){
			
		},
		complete:function(){
			
		}
	});
}
/*类型 初始ajax*/
function ajaxPost($scope,$http,id,page){
	var billId=localStorage.getItem("billId");
	if(billId==null){
		billId="";
	}
	if($("#billId").val()!=""){
		var billId=$("#billId").val();
	}
	var data={'page':page,'pageSize':'10','keyWords':'','sortType':'showSeq','categoryId':id,'billId':billId};
	var ctx=$("#ctx").val();
	var url=ctx+"/h5/h5OrderPo?r="+Math.random();
	$http({method:'POST',params:data,url:url}).success(function(data) {
		$("#div_shade").remove();
		if(data.statusCode=="0000"){
			$("#categoryId").val("");
			$scope.xdVar=false;
			$scope.lists=data.objectzJson.dishesList;
			$scope.categorys=data.objectzJson.categoryList;
			$scope.allMoney=data.objectzJson.oriCost;
			$scope.allTotal=data.objectzJson.billCount;
			for(var i=0;i<data.objectzJson.dishesList.length;i++){
				if(data.objectzJson.dishesList[i].dishesCount=='0'){
					$scope.lists[i].dishesCount="";
				}else{
					$scope.lists[i].disheupanddown=true;
					$scope.yVar=true;
					$scope.nVar=false;
					$scope.totalnum=true;
					$scope.showmoney=true;
				}
			}
			for(var i=0;i<data.objectzJson.categoryList.length;i++){
				if(data.objectzJson.categoryList[i].categoryCount==0){
					$scope.categorys[i].categoryCount="";
				}else{
					$scope.categorys[i].upanddown=true;
				}
			}
		}
		if(data.statusCode=="1007"){
			
		}
    }).error(function(data) {
    	$("#div_shade").remove();
        alert('请求错误');
    });
}
//下单ajax方法
function xdAjaxPost($http,$scope,billId){
	var ctx=$("#ctx").val();
	var url=ctx+"/h5/placeOrder";
	$http({method:'POST',params:{billId:billId},url:url}).success(function(data) {
		if(data.statusCode=="0000"){
			window.location.href=ctx+'/h5/placeOrderPage?billId='+billId;
		}else{
			$.messager.alert("提示", data.message,"error");
		}
    }).error(function(data) {
    	alert('请求错误');
    });
}
