package org.terra.company.rest;

import static com.jayway.restassured.RestAssured.delete;
import static com.jayway.restassured.RestAssured.get;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.terra.company.model.Company;
import org.terra.company.model.Person;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CompanyEndpointIT {

    private static final String COMPANY_REST_URL = "http://localhost:8080/company/rest/companies";

    private String expectedOwnerFirstName = "John";
    private String expectedOwnerLastName = "Gray";
    private String expectedOwnerEmail = "John.Gray@mail";

    private String expectedEmployeeFirstName = "Dan";
    private String expectedEmployeeLastName = "Kane";
    private String expectedEmployeeEmail = "Dan.Kane@mail";

    @Test
    public void testGetCompany() throws JsonProcessingException {

        String expectedName = "Nova";
        String expectedAddress = "blue lagoon";
        String expectedCity = "Amsterdam";
        String expectedCountry = "Netherlands";
        String expectedEmail = "nova@mail";

        Long companyId = this.createCompany(expectedAddress, expectedCity, expectedCountry, expectedEmail, expectedName)
                .getId();

        get(COMPANY_REST_URL + "/" + companyId).then().body("name", equalTo(expectedName))
                .body("address", equalTo(expectedAddress)).body("city", equalTo(expectedCity))
                .body("country", equalTo(expectedCountry));
    }

    @Test
    public void testUpdateCompany() throws JsonProcessingException {

        String expectedName = "Nova";
        String expectedAddress = "Roses Lagoon";
        String expectedCity = "Amsterdam";
        String expectedCountry = "Netherlands";
        String expectedEmail = "nova@mail";

        String updatedName = "Novaly";
        String updatedAddress = "Roses Vue";
        String updatedCity = "Bruxelles";
        String updatedCountry = "Belgium";
        String updatedEmail = "rossa@mail";

        Long companyId = this.createCompany(expectedAddress, expectedCity, expectedCountry, expectedEmail, expectedName)
                .getId();
        Company company = this.buildCompany(updatedAddress, updatedCity, updatedCountry, updatedEmail, updatedName);
        company.setId(companyId);
        ObjectMapper mapper = new ObjectMapper();
        String jsonInString = mapper.writeValueAsString(company);
        given().contentType("application/json").body(jsonInString).when().put(COMPANY_REST_URL + "/" + companyId);

        get(COMPANY_REST_URL + "/" + companyId).then().body("name", equalTo(updatedName))
                .body("city", equalTo(updatedCity)).body("address", equalTo(updatedAddress));
    }

    @Test
    public void testDeleteCompany() throws JsonProcessingException {

        String expectedName = "Nova";
        String expectedAddress = "blue lagoon";
        String expectedCity = "Amsterdam";
        String expectedCountry = "Netherlands";
        String expectedEmail = "nova@mail";

        Long companyId = this.createCompany(expectedAddress, expectedCity, expectedCountry, expectedEmail, expectedName)
                .getId();
        delete(COMPANY_REST_URL + "/" + companyId);
        get(COMPANY_REST_URL + "/" + companyId).then().statusCode(404);
    }

    @Test
    public void testAddOwner() throws JsonProcessingException {

        String expectedName = "Nova";
        String expectedAddress = "Roses Lagoon";
        String expectedCity = "Amsterdam";
        String expectedCountry = "Netherlands";
        String expectedEmail = "nova@mail";

        String ownerFirstName = "Adam";
        String ownerLastName = "Ewing";

        Long companyId = this.createCompany(expectedAddress, expectedCity, expectedCountry, expectedEmail, expectedName)
                .getId();
        Person owner = this.buildCompanyOwner(ownerFirstName, ownerLastName);

        ObjectMapper mapper = new ObjectMapper();
        String jsonInString = mapper.writeValueAsString(owner);
        given().contentType("application/json").body(jsonInString).when()
                .post(COMPANY_REST_URL + "/owner/" + companyId);

        Company company = get(COMPANY_REST_URL + "/" + companyId).as(Company.class);
        assertTrue("Added owner not found", company.getOwner().contains(owner));
    }

    @Test
    public void testCreateCompanyInvalidEmail() throws JsonProcessingException {
        String name = "Nova";
        String address = "Roses Lagoon";
        String city = "Amsterdam";
        String country = "Netherlands";
        String email = "nova-mail";

        Company company = this.buildCompany(address, city, country, email, name);

        ObjectMapper mapper = new ObjectMapper();
        String jsonInString = mapper.writeValueAsString(company);

        // a proper test will check the response and not only the returned status code (404 can be returned for multiple reasons)
        // the response is wildfly specific in it's current form and to introduce jboss imports
        // (https://github.com/resteasy/Resteasy/blob/master/jaxrs/providers/resteasy-validator-provider-11/src/main/java/org/jboss/resteasy/api/validation/ResteasyViolationException.java)
        // that will stain the code and reduce code portability
        given().contentType("application/json").body(jsonInString).when().post(COMPANY_REST_URL).then().statusCode(400);
    }

    @Test
    @Ignore
    public void testCreateCompanyNoOwner() throws JsonProcessingException {
        // TODO - creating a company with no owner should fail
    }

    @Test
    @Ignore
    public void testCreateCompanyNoEmployee() throws JsonProcessingException {
        // TODO - creating a company with no employee(s) should fail
    }

    public Company createCompany(String address, String city, String country, String email, String name)
            throws JsonProcessingException {
        Company company = this.buildCompany(address, city, country, email, name);

        ObjectMapper mapper = new ObjectMapper();
        String jsonInString = mapper.writeValueAsString(company);

        return given().contentType("application/json").body(jsonInString).when().post(COMPANY_REST_URL)
                .as(Company.class);
    }

    private Company buildCompany(String address, String city, String country, String email, String name) {
        Company company = new Company();
        company.setAddress(address);
        company.setCity(city);
        company.setCountry(country);
        company.setEmail(email);
        company.setName(name);
        List<Person> employeeList = new ArrayList<>();
        employeeList.add(
                this.buildCompanyOwner(expectedEmployeeFirstName, expectedEmployeeLastName));
        company.setEmployee(employeeList);
        List<Person> companyOwnerList = new ArrayList<>();
        companyOwnerList.add(this.buildCompanyOwner(expectedOwnerFirstName, expectedOwnerLastName));
        company.setOwner(companyOwnerList);
        return company;
    }

    private Person buildCompanyOwner(String firstName, String lastName) {
        Person companyOwner = new Person();
        companyOwner.setFirstName(firstName);
        companyOwner.setLastName(lastName);
        return companyOwner;
    }
}
