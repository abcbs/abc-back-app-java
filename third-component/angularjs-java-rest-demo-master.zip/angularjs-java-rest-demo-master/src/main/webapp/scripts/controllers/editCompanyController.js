angular.module('companyDemo').controller('EditCompanyController', function($scope, $routeParams, $location, CompanyResource) {

  $scope.get = function() {
    var successCallback = function(data) {
      self.original = data;

      $scope.company = new CompanyResource(self.original);
    };
    var errorCallback = function() {
      $location.path("/company");
    };
    CompanyResource.get({
      CompanyId: $routeParams.CompanyId
    }, successCallback, errorCallback);
  };

  $scope.isClean = function() {
    return angular.equals(self.original, $scope.company);
  };

  $scope.addEmployee = function() {
    var newEmployee = {};
    newEmployee.firstName = '';
    newEmployee.lastName = '';
    $scope.company.employee.push(newEmployee);
  };

  $scope.addOwner = function() {
    var newOwner = {};
    newOwner.firstName = '';
    newOwner.lastName = '';
    $scope.company.owner.push(newOwner);
  };

  $scope.save = function() {
    var successCallback = function() {
      $scope.get();
    };
    $scope.company.$update(successCallback);
  };

  $scope.cancel = function() {
      $location.path("/company");
  };

  $scope.get();
});
