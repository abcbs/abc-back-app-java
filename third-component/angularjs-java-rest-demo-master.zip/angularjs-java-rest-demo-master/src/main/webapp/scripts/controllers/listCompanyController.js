angular.module('companyDemo').controller('ListCompanyController', function($scope, CompanyResource) {

  $scope.companies = CompanyResource.query();
});
