angular.module('companyDemo').controller('NewCompanyController', function($scope, $location, CompanyResource) {

  $scope.$location = $location;
  $scope.company = $scope.company || {};
  $scope.company.employee = [];
  $scope.company.owner = [];

  $scope.save = function() {
    var successCallback = function(data, responseHeaders) {
      $location.path('/company');
    };
    CompanyResource.save($scope.company, successCallback);
  };

  $scope.addEmployee = function() {
    var newEmployee = {};
    newEmployee.firstName = '';
    newEmployee.lastName = '';
    $scope.company.employee.push(newEmployee);
  };

  $scope.addOwner = function() {
    var newOwner = {};
    newOwner.firstName = '';
    newOwner.lastName = '';
    $scope.company.owner.push(newOwner);
  };

  $scope.cancel = function() {
    $location.path("/company");
  };
});
