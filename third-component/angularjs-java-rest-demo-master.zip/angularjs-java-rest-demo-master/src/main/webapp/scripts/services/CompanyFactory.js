angular.module('companyDemo').factory('CompanyResource', function($resource){
    var resource = $resource('rest/companies/:CompanyId',{CompanyId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:true},'update':{method:'PUT'}});
    return resource;
});
