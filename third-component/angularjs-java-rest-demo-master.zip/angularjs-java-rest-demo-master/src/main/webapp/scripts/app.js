var app = angular.module('companyDemo', ['ngRoute', 'ngResource']);

app.config(['$routeProvider', function($routeProvider) {
  $routeProvider

  // route for the home page
    .when('/', {
    templateUrl: 'views/landing.html',
    controller: 'mainController'
  })

  .when('/company/edit/:CompanyId', {
      templateUrl: 'views/company/edit.html',
      controller: 'EditCompanyController'
    })

    .when('/company/new', {
      templateUrl: 'views/company/edit.html',
      controller: 'NewCompanyController'
    })
    // route for the company details page
    .when('/company', {
      templateUrl: 'views/company/detail.html',
      controller: 'ListCompanyController'
    });
}]);

app.controller('mainController', function($scope) {
  // create a message to display in our view
  $scope.message = 'Acasa ';
});

app.controller('NavController', function($scope, $location) {
  $scope.matchesRoute = function(route) {
    var path = $location.path();
    return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
  }
});
