package org.terra.company.rest;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.terra.company.dao.CompanyDao;
import org.terra.company.model.Company;
import org.terra.company.model.Person;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;


/**
 * 
 */
@Stateless
@Path("/companies")
@Api(value="/companies", description = "Company CRUD operations")
public class CompanyEndpoint {

    @Inject
    private CompanyDao companyDao;

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @ApiOperation(value="Create company", response = Company.class)
    public Response create(@ApiParam( value = "Company", required = true ) @Valid Company entity) {
        if(entity.getOwner().isEmpty()) {
            return Response.status(Status.BAD_REQUEST).entity("Invalid request: At least one owner needs to be specified").build();
        }
        if(entity.getEmployee().isEmpty()) {
            return Response.status(Status.BAD_REQUEST).entity("Invalid request: At least one employee needs to be specified").build();
        }
        this.companyDao.create(entity);
        return Response.ok(entity).build();
    }

    @DELETE
    @Path("/{id:[0-9][0-9]*}")
    public Response deleteById(@PathParam("id") Long id) {
        this.companyDao.delete(id);
        return Response.noContent().build();
    }

    @GET
    @Path("/{id:[0-9][0-9]*}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response findById(@PathParam("id") Long id) {
        Company entity = this.companyDao.findById(id);

        if (entity == null) {
            return Response.status(Status.NOT_FOUND).build();
        }
        return Response.ok(entity).build();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Company> listAll() {
        return this.companyDao.getAll();
    }

    @PUT
    @Path("/{id:[0-9][0-9]*}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("id") Long id, Company entity) {
        if (entity == null) {
            return Response.status(Status.BAD_REQUEST).build();
        }
        if (id == null) {
            return Response.status(Status.BAD_REQUEST).build();
        }
        if (!id.equals(entity.getId())) {
            return Response.status(Status.CONFLICT).entity(entity).build();
        }
        if(entity.getOwner().isEmpty()) {
            return Response.status(Status.BAD_REQUEST).entity("Invalid request: At least one owner needs to be specified").build();
        }
        if(entity.getEmployee().isEmpty()) {
            return Response.status(Status.BAD_REQUEST).entity("Invalid request: At least one employee needs to be specified").build();
        }
        this.companyDao.update(entity);
        return Response.noContent().build();
    }

    @POST
    @Path("/owner/{id:[0-9][0-9]*}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response addOwner(@PathParam("id") Long companyId, @Valid Person entity) {
        this.companyDao.addOwner(companyId, entity);
        return Response.ok().build();
    }
}
