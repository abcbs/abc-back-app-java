package org.terra.company.model;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import org.terra.company.validation.Email;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@XmlRootElement
@ApiModel( value = "Company", description = "Company model representation" )
public class Company {

    @ApiModelProperty( value = "Company's id", required = false )
    private Long id;

    @NotNull
    @Size(min = 1, max = 200)
    @ApiModelProperty( value = "Company's name", required = true )
    private String name;

    @NotNull
    @Size(min = 1, max = 150)
    @ApiModelProperty( value = "Company's address", required = true )
    private String address;

    @NotNull
    @Size(min = 1, max = 20)
    @ApiModelProperty( value = "Company's city", required = true )
    private String city;

    @NotNull
    @Size(min = 1, max = 20)
    @ApiModelProperty( value = "Company's country", required = true )
    private String country;

    @Size(max = 20)
    @Email
    @ApiModelProperty( value = "Company's email", required = false )
    private String email;

    @Size(max = 20)
    @ApiModelProperty( value = "Company's telephone", required = false )
    private String telephone;

    @ApiModelProperty( value = "Company's list of emmployees", required = true, dataType = "List[org.terra.company.model.Person]" )
    private List<Person> employee = new ArrayList<>();

    @ApiModelProperty( value = "Company's list of onwers", required = true, dataType = "List[org.terra.company.model.Person]" )
    private List<Person> owner = new ArrayList<>();

    public Long getId() {
        return this.id;
    }

    public void setId(final Long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Company)) {
            return false;
        }
        Company other = (Company) obj;
        if (id != null) {
            if (!id.equals(other.id)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    @Override
    public String toString() {
        String result = getClass().getSimpleName() + " ";
        if (name != null && !name.trim().isEmpty())
            result += "name: " + name;
        if (address != null && !address.trim().isEmpty())
            result += ", address: " + address;
        if (city != null && !city.trim().isEmpty())
            result += ", city: " + city;
        if (country != null && !country.trim().isEmpty())
            result += ", country: " + country;
        if (email != null && !email.trim().isEmpty())
            result += ", email: " + email;
        if (telephone != null && !telephone.trim().isEmpty())
            result += ", telephone: " + telephone;
        return result;
    }

    public List<Person> getEmployee() {
        return this.employee;
    }

    public void setEmployee(final List<Person> employee) {
        this.employee = employee;
    }

    public List<Person> getOwner() {
        return this.owner;
    }

    public void setOwner(final List<Person> owner) {
        this.owner = owner;
    }

    public void addOwner(Person owner) {
        this.owner.add(owner);
    }
}
