package org.terra.company.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import javax.ejb.Stateless;

import org.terra.company.model.Company;
import org.terra.company.model.Person;

/**
 * 
 */
@Stateless
public class CompanyDao {


    private static final ConcurrentHashMap<Long, Company> COMPANIES = new ConcurrentHashMap<>();
    private static final AtomicLong ID_GENERATOR = new AtomicLong();

    public void create(Company company) {
        company.setId(ID_GENERATOR.getAndIncrement());
        COMPANIES.put(company.getId(), company);
    }

    public Company findById(Long pid) {
        return COMPANIES.get(pid);
    }

    public void update(Company company) {
        if(findById(company.getId()) != null) {
            COMPANIES.put(company.getId(), company);
        }
    }

    public void delete(Long id) {
        COMPANIES.remove(id);
    }

    public List<Company> getAll() {
        return Collections.unmodifiableList(new ArrayList<>(COMPANIES.values()));
    }

    public void addOwner(Long companyId, Person owner) {
        Company company = COMPANIES.get(companyId);
        if(company == null) {
            return;
        }
        company.addOwner(owner);
    }
}
