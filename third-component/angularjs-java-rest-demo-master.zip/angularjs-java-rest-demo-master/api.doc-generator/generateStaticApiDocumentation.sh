#!/bin/bash


# https://github.com/swagger-api/swagger-core/wiki/Swagger-Core-RESTEasy-2.X-Project-Setup-1.5

wget http://repo1.maven.org/maven2/io/swagger/swagger-codegen-cli/2.1.4/swagger-codegen-cli-2.1.4.jar -O swagger-codegen-cli.jar
java -jar swagger-codegen-cli.jar generate \
        -i http://localhost:8080/company/rest/swagger.json \
        -l html \
        -o .
