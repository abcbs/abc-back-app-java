//
//  GoodsShelvesMode.h
//  G2TestDemo
//
//  Created by wjy on 16/2/24.
//  Copyright © 2016年 ws. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GoodsShelvesMode : NSObject

/*proId
 商品Id
 trademark
 品牌
 officialBarCode
 官方条码
 name
 名称
 proDesc
 描述
 itemNo
 产品型号
 recommendedPrice
 官方建议价
 pic
 图片
 quantity
 数量（库存）
 primeCost
 进货价
 price
 销售价格（商品页面显示价格）
 discount
 折扣比例
 privilege
 优惠金额
 promotionStatus
 促销状态（0不促销1促销）
 promotionPrice
 促销价格
 barCode
 条码
 affterDiscount
 折后价
 restId
 店Id
 status
 可用状态（0下架1可用）
 categoryToneIos
 ios颜色值
 categoryToneAndroid
 android颜色值
 categoryName
 产品分类名称
 proColorNo
 产品色号
 specsId
 规格ID
 specsName
 规格
 volume
 单位
 size
 规格尺寸
 capacity
 容量
 remarks
 备注
 */

@property(nonatomic,copy)NSString *page;
@property(nonatomic,copy)NSString *proId;
@property(nonatomic,copy)NSString *trademark;
@property(nonatomic,copy)NSString *officialBarCode;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *proDesc;
@property(nonatomic,copy)NSString *itemNo;
@property(nonatomic,copy)NSString *recommendedPrice;
@property(nonatomic,copy)NSString *pic;
@property(nonatomic,copy)NSString *quantity;
@property(nonatomic,copy)NSString *primeCost;
@property(nonatomic,copy)NSString *price;
@property(nonatomic,copy)NSString *discount;
@property(nonatomic,copy)NSString *privilege;
@property(nonatomic,copy)NSString *promotionStatus;
@property(nonatomic,copy)NSString *promotionPrice;
@property(nonatomic,copy)NSString *barCode;
@property(nonatomic,copy)NSString *affterDiscount;
@property(nonatomic,copy)NSString *restId;
@property(nonatomic,copy)NSString *status;
@property(nonatomic,copy)NSString *categoryToneIos;
@property(nonatomic,copy)NSString *categoryToneAndroid;
@property(nonatomic,copy)NSString *categoryName;
@property(nonatomic,copy)NSString *proColorNo;
@property(nonatomic,copy)NSString *specsId;
@property(nonatomic,copy)NSString *specsName;
@property(nonatomic,copy)NSString *volume;
@property(nonatomic,copy)NSString *size;
@property(nonatomic,copy)NSString *capacity;
@property(nonatomic,copy)NSString *remarks;


@end
