//
//  JY3cLoginManager.h
//  G2TestDemo
//
//  Created by NDlan on 16/1/9.
//  Copyright © 2016年 ws. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NDLTransferHeader.h"
#import "JY3cLoginManager.h"
@interface MaLoginManager : JY3cLoginManager



@end
