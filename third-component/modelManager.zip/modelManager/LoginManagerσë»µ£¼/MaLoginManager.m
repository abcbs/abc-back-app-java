//
//  JY3cLoginManager.m
//  G2TestDemo
//
//  Created by NDlan on 16/1/9.
//  Copyright © 2016年 ws. All rights reserved.
//
#define  WangWei    @"http://192.168.1.158:8080"
#import "MaLoginManager.h"
#import "NDLCoreBusincessHeader.h"
#import "JYModelConfigureHeader.h"
#import "JY3cAccountModel.h"

#import "NDLBusinessConfigure.h"
//#import "NDLModelConfigure.h"  NDL_JY_URL
#import "Common.h"

@implementation MaLoginManager

-(void)login:(NSString *)accountNumber withFirst:(NSString *)first withPassword:(NSString *)password block:(NDlHttpResponse)block{

    
    
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/login/appLogin"];

    
    NSString *str = [NSString stringWithFormat:@"%@,%@",accountNumber,first ];

    NSDictionary *dic = @{
                          @"username":str,
                          @"password":password
                          
                          };

    
     HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    

    
    [http postWithFormCustomedError:urlStr parameters:dic modelClass: [JY3cAccountModel class] keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"response:%@",response);
        
        
        
        if (response) {
            
            if (block) {
                
                block(response,nil);
            }
        }
        
        if (bsErrorMessage) {
            if (block) {
                block(nil,bsErrorMessage);
            }
        }
        
    }];

    
}

//logout

- (void)requestLogout{
    
    NSString *urlStr = [NSString stringWithFormat:@"/base3c/mobileLogout?returnJson=true"];
    
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    [http postWithForm:urlStr parameters:nil modelClass:nil keyPath:@"iosReturnJson"  block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"response:%@",response);
        
        
    }];

}
//请求验证码get
- (void)requestPhone:(NSString *)phone block:(NDlHttpResponse)block{
    
    NSString *urlStr = [NSString stringWithFormat:@"/base3c/forget/sendSms?returnJson=true&phone=%@",phone];
    
    
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:NO];
    

    [http getWithForm:urlStr pathPattern:@"phone" modelClass:nil keyPath:@"iosReturnJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"responseObject:%@",response);
        
        
        if (response) {
            if (block) {
                block(response,bsErrorMessage);
            }
        }
        

    }];
    

}

//重置密码
- (void)resetPassword:(NSString *)phone withCode:(NSString *)code withLoginPassword:(NSString *)password block:(NDlHttpResponse)block{
    
    NSString *urlStr = [NSString stringWithFormat:@"/base3c/forget/resetPassWord?returnJson=true"];
    
    
    NSDictionary *dic = @{
                          @"phone":phone,
                           @"code":code,
                           @"loginPassword":password
                          
                          };
    
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
  
    
    [http postWithFormCustomedError:urlStr parameters:dic modelClass:nil keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
                   
        NSLog(@"response:%@",response);
                   
       
      
        if (response != nil) {
            
            if (block) {
                
                block(response,nil);
                       }
        }
        
        if (bsErrorMessage != nil)
        {
            if (block) {

                block(nil,bsErrorMessage);
            }
        }
        
               }];
    

    
}


@end
