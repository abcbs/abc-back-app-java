//
//  MAGouWuCheManager.h
//  G2TestDemo
//
//  Created by NDlan on 16/2/22.
//  Copyright © 2016年 ws. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NDLTransferHeader.h"
@interface MAGouWuCheManager : NSObject
+(MAGouWuCheManager *) gouWuCheManager;
//查看购物车
-(void)requestMaShopCarDataWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
//查看购物车详情
- (void)requestMaShopCarDetailWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
//清空购物车
- (void)MaShopCarWithUrl:(NSString *)url  WithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
//收货地址
- (void)MaDeliveryAddressWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
///b2b-main/order/createOrder
//结算
- (void)JieSuanWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
@end
