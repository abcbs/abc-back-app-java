//
//  BaseModel.h
//  G2TestDemo
//
//  Created by iOS  on 16/2/25.
//  Copyright © 2016年 ws. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModelManager : NSObject
//- (NSObject )returnModelWithClass:(Class )modelClass withDic:(NSDictionary *)dic;
- (id)initWithDic:(NSDictionary *)jsonDic ;
@end
