//
//  MAGouWuCheManager.m
//  G2TestDemo
//
//  Created by NDlan on 16/2/22.
//  Copyright © 2016年 ws. All rights reserved.
//

#import "MAGouWuCheManager.h"
#import "B2bShoppingCart.h"
#import "B2bShoppingCartDetail.h"
#import "JYModelConfigureHeader.h"
#import "B2bDeliveryAddress.h"
@implementation MAGouWuCheManager
+(MAGouWuCheManager *) gouWuCheManager{

    static MAGouWuCheManager *instance;
    if (!instance) {
        instance=[[super allocWithZone:nil]init];
    }
    return instance;
}

- (instancetype)init {
    if ((self = [super init]) != nil) {
        
        
    }
    return self;
}
//http://192.168.1.227:8080/b2b-main/b2bShoppingCart/getCart
-(void)requestMaShopCarDataWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block{

    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/b2bShoppingCart/getCart"];
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    [http postWithFormCustomedError:urlStr parameters:queryDic modelClass:[B2bShoppingCart class] keyPath:@"iosReturnJson/objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        if (bsErrorMessage) {
            if (bsErrorMessage.message.length > 0 ) {
                NSLog(@"ShopCarData   bsErrorMessage:%@",bsErrorMessage);
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提醒" message:bsErrorMessage.message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                [alertView show];
                return ;
            }
            
            
        }
        if (response) {
            if (block) {
                block(response,nil);
                
            }
        }
        
    }];



}

- (void)requestMaShopCarDetailWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block{
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/b2bShoppingCart/getB2bCartDetail"];
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    [http postWithFormCustomedError:urlStr parameters:queryDic modelClass:[B2bShoppingCartDetail class] keyPath:@"iosReturnJson/objectzJson"  block:^(id response, ErrorMessage *bsErrorMessage) {
        
        
        NSLog(@"商品详情%@",response);
        if (bsErrorMessage.message.length > 0) {
            
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提醒" message:bsErrorMessage.message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            return ;
        }else if (response){
            
            if (block) {
                block(response,nil);
            }
        }
        
    }];
}


- (void)MaShopCarWithUrl:(NSString *)urlStr WithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block{
    

    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:NO];
    [http postWithFormCustomedError:urlStr parameters:queryDic modelClass:nil keyPath:@"iosReturnJson"  block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSString *statusCode = response[@"iosReturnJson"][@"statusCode"];
        if ([statusCode isEqualToString:@"0000"]) {
            
            block(response , nil);
        }else if([statusCode isEqualToString:@"1000"]){
            
            
            NSString *message  = response [@"iosReturnJson"][@"message"];
            
            if (message.length > 0) {
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提醒" message:message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                [alertView show];
            }
            
            
            return ;
        }

        
    }];

    
    
}

//收货地址
- (void)MaDeliveryAddressWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block{
        NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/order/queryOrderAddress"];
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    [http postWithFormCustomedError:urlStr parameters:queryDic modelClass:[B2bDeliveryAddress class] keyPath:@"iosReturnJson/objectzJson/b2bDeliveryAddresslist"  block:^(id response, ErrorMessage *bsErrorMessage) {
        
        if (bsErrorMessage.message.length > 0) {
            
            UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提醒" message:bsErrorMessage.message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
            [alertView show];
            return ;
        }else if (response){
            
            if (block) {
                block(response,nil);
            }
        }
        
        
        
    }];

    
}

//结算
- (void)JieSuanWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block{
    
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/order/createOrder"];
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:NO];
    [http postWithFormCustomedError:urlStr parameters:queryDic modelClass:nil keyPath:@"iosReturnJson/objectzJson/b2bDeliveryAddresslist"  block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSString *statusCode = response[@"iosReturnJson"][@"statusCode"];
        if ([statusCode isEqualToString:@"0000"]) {
            
            block(response , nil);
        }else if([statusCode isEqualToString:@"1000"]){
            
            
            NSString *message  = response [@"iosReturnJson"][@"message"];
            
            if (message.length > 0) {
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提醒" message:message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                [alertView show];
            }
            
            
            return ;
        }
        
        
        
    }];

    
    
}
@end
