//
//  MAInventorymanagementManager.h
//  G2TestDemo
//
//  Created by wjy on 16/2/26.
//  Copyright © 2016年 ws. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NDLTransferHeader.h"
@interface MAInventorymanagementManager : NSObject
//库存明细
-(void)TheInventoryDetailWith:(NSDictionary *)dic block:(NDlHttpResponse)block;

@end
