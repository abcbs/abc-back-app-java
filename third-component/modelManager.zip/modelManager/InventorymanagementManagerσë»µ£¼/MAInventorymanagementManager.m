//
//  MAInventorymanagementManager.m
//  G2TestDemo
//
//  Created by wjy on 16/2/26.
//  Copyright © 2016年 ws. All rights reserved.
//

#import "MAInventorymanagementManager.h"
#import "JYModelConfigureHeader.h"
#import "B2bInventoryHead.h"
@implementation MAInventorymanagementManager
//库存明细
-(void)TheInventoryDetailWith:(NSDictionary *)dic block:(NDlHttpResponse)block{

    NSString *url=[NSString stringWithFormat:@"/b2b-main/inventory/getList"];
    HttpTool *http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    [http postWithForm:url parameters:dic modelClass:[B2bInventoryHead class] keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        if (response) {
            if (block) {
                block(response,nil);
            }
        }
    }];

}
@end
