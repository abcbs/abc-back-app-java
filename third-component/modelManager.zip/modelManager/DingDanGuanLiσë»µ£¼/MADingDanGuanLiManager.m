//
//  MADingDanGuanLiManager.m
//  G2TestDemo
//
//  Created by NDlan on 16/2/22.
//  Copyright © 2016年 ws. All rights reserved.
//

#import "MADingDanGuanLiManager.h"
#import "JYModelConfigureHeader.h"
#import "B2bOrderPkg.h"
#import "B2bOrderItem.h"
#import "B2bOrderRmtPkg.h"
#import "B2bOrderRmtDetail.h"


@implementation MADingDanGuanLiManager
//订单管理
- (void)dingDanGuanLiReuqest:(NSDictionary *)dic block:(NDlHttpResponse)block{
    
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/order/queryOrderPkgList"];
    
    HttpTool *http = [HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    
    [http postWithFormCustomedError:urlStr parameters:dic modelClass:[B2bOrderPkg class] keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"response:%@",response);
        
        
        if (response) {
            
            if (block) {
                block(response,nil);
            }
        }
        
        if (bsErrorMessage) {
            if (block) {
                block(nil,bsErrorMessage);
            }
        }
        
    }];

}

//订单管理详情
- (void)dingDanDetailReuqest:(NSDictionary *)dic block:(NDlHttpResponse)block{
    
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/order/queryOrderItemList"];
    
    HttpTool *http = [HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    
    [http postWithFormCustomedError:urlStr parameters:dic modelClass:[B2bOrderItem class] keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"response:%@",response);
        
        
        if (response) {
            
            if (block) {
                block(response,nil);
            }
        }
        
        if (bsErrorMessage) {
            if (block) {
                block(nil,bsErrorMessage);
            }
        }
        
    }];

}
//补货管理
- (void)buHuoRequest:(NSDictionary *)dic block:(NDlHttpResponse)block{
    
    
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/orderRmt/getList"];
    
    
    HttpTool *http = [HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    
    [http postWithFormCustomedError:urlStr parameters:dic modelClass:[B2bOrderRmtPkg class] keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"response:%@",response);
        
        
        if (response) {
            
            if (block) {
                block(response,nil);
            }
        }
        
        if (bsErrorMessage) {
            if (block) {
                block(nil,bsErrorMessage);
            }
        }
        
    }];
    

}
//补货详情
- (void)buHuoDetailRequest:(NSDictionary *)dic block:(NDlHttpResponse)block{
    
    
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/orderRmt/getList"];
    
    
    HttpTool *http = [HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    
    [http postWithFormCustomedError:urlStr parameters:dic modelClass:[B2bOrderRmtDetail class] keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"response:%@",response);
        
        
        if (response) {
            
            if (block) {
                block(response,nil);
            }
        }
        
        if (bsErrorMessage) {
            if (block) {
                block(nil,bsErrorMessage);
            }
        }
        
    }];
    
    
}
//确认补货
- (void)queRenBuHuoRequest:(NSDictionary *)dic block:(NDlHttpResponse)block{
    
    
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/orderRmt/confirm"];
    
    HttpTool *http = [HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    
    [http postWithFormCustomedError:urlStr parameters:dic modelClass:nil keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"response:%@",response);
        
        
        if (response) {
            
            if (block) {
                block(response,nil);
            }
        }
        
        if (bsErrorMessage) {
            if (block) {
                block(nil,bsErrorMessage);
            }
        }
        
    }];
    

}
//取消订单
- (void)cancelDingDanRequest:(NSDictionary *)dic block:(NDlHttpResponse)block{
    
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/order/updateOrderPkgStatus"];
    
    HttpTool *http = [HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    
    [http postWithFormCustomedError:urlStr parameters:dic modelClass:nil keyPath:@"objectzJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        
        NSLog(@"response:%@",response);
        
        
        if (response) {
            
            if (block) {
                block(response,nil);
            }
        }
        
        if (bsErrorMessage) {
            if (block) {
                block(nil,bsErrorMessage);
            }
        }
        
    }];
    
    
}


@end
