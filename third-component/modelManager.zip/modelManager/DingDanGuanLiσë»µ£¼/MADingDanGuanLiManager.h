//
//  MADingDanGuanLiManager.h
//  G2TestDemo
//
//  Created by NDlan on 16/2/22.
//  Copyright © 2016年 ws. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NDLTransferHeader.h"
@interface MADingDanGuanLiManager : NSObject
- (void)dingDanGuanLiReuqest:(NSDictionary *)dic block:(NDlHttpResponse)block;
- (void)dingDanDetailReuqest:(NSDictionary *)dic block:(NDlHttpResponse)block;
- (void)buHuoRequest:(NSDictionary *)dic block:(NDlHttpResponse)block;
- (void)buHuoDetailRequest:(NSDictionary *)dic block:(NDlHttpResponse)block;
- (void)queRenBuHuoRequest:(NSDictionary *)dic block:(NDlHttpResponse)block;
- (void)cancelDingDanRequest:(NSDictionary *)dic block:(NDlHttpResponse)block;


@end
