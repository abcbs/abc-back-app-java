//
//  MAZhangHuGuanLiManager.h
//  G2TestDemo
//
//  Created by NDlan on 16/2/22.
//  Copyright © 2016年 ws. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NDLTransferHeader.h"
#import "threeCShouYinYuanGuanLiProtocol.h"
@interface MAZhangHuGuanLiManager : NSObject<threeCShouYinYuanGuanLiProtocol>
//收银员管理列表
-(void)cashierWith:(NSDictionary *)dic block:(NDlHttpResponse)block;
//创建收银员

-(void)createCashierWith:(NSDictionary *)createCashier block:(NDlHttpResponse)block;
//修改收银员
-(void)ModifyCashierWith:(NSDictionary *)modifyCashier block:(NDlHttpResponse)block;
@end
