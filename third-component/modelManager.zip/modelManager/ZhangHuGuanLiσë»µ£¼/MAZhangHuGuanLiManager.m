//
//  MAZhangHuGuanLiManager.m
//  G2TestDemo
//
//  Created by NDlan on 16/2/22.
//  Copyright © 2016年 ws. All rights reserved.
//

#import "MAZhangHuGuanLiManager.h"
#import "threeCShouYinYaun.h"

#import "JYModelConfigureHeader.h"

@implementation MAZhangHuGuanLiManager
//请求

//收银员管理列表
-(void)cashierWith:(NSDictionary *)dic block:(NDlHttpResponse)block{
    // NSLog(@"%ld",shouyinyuan.page);
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/warehouseKeeper/getList"];
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    [http postWithForm:urlStr parameters:dic modelClass:[threeCShouYinYaun class] keyPath:@"objectzJson" block:^(id responseObject, ErrorMessage *bsErrorMessage) {
        NSLog(@"responseObject:%@",responseObject);
        
        if (responseObject) {
            if (block) {
                block(responseObject,nil);
            }
        }
        
    }];
    
    
}


//创建收银员

-(void)createCashierWith:(NSDictionary *)createCashier block:(NDlHttpResponse)block{
    NSString *url=[NSString stringWithFormat:@"/b2b-main/warehouseKeeper/add"];
    HttpTool *http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    [http postWithFormCustomedError:url parameters:createCashier modelClass:nil keyPath:@"iosReturnJson" block:^(id responseObject, ErrorMessage *bsErrorMessage) {
        
        
        if (bsErrorMessage) {
            if (block) {
                block(nil,bsErrorMessage);
            }
        } else{
            NSLog(@"%@",bsErrorMessage);
            
            if (block) {
                block(responseObject,nil);
            }
            
            
        }
        
    }];
    
    /*
     [http postWithForm:url parameters:createCashier modelClass:nil keyPath:@"iosReturnJson" block:^(id responseObject, ErrorMessage *bsErrorMessage) {
     NSLog(@"responseObject:%@",responseObject);
     NSLog(@"%@",bsErrorMessage);
     if (responseObject) {
     if (block) {
     block(responseObject,nil);
     }
     }
     }];
     */
}
//修改收银员
-(void)ModifyCashierWith:(NSDictionary *)modifyCashier block:(NDlHttpResponse)block{
    
    NSString *url=[NSString stringWithFormat:@"/b2b-main/warehouseKeeper/update"];
    HttpTool *http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    [http postWithFormCustomedError:url parameters:modifyCashier modelClass:nil keyPath:@"iosReturnJson" block:^(id responseObject, ErrorMessage *bsErrorMessage) {
        
        if (responseObject) {
            if (block) {
                block(responseObject,bsErrorMessage);
            }
        }
        else {
            NSLog(@"%@",bsErrorMessage);
            
            if (block) {
                block(nil,bsErrorMessage);
            }
            
            
        }
        
        
    }];
    /*[http postWithForm:url parameters:modifyCashier modelClass:[threeCShouYinYaun class] keyPath:@"iosReturnJson" block:^(id responseObject, ErrorMessage *bsErrorMessage) {
     
     NSLog(@"responseObject:%@",responseObject);
     
     if (responseObject) {
     if (block) {
     block(responseObject,nil);
     }
     }
     
     }];
     */
    
}


@end
