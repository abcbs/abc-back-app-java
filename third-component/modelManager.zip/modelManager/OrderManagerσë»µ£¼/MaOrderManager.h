//
//  MaOrderManager.h
//  G2TestDemo
//
//  Created by iOS  on 16/2/18.
//  Copyright © 2016年 ws. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NDLTransferHeader.h"
@interface MaOrderManager : NSObject
+(MaOrderManager *) maOrderManager;
//商品页面信息
-(void)obtainMaProductInfoWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
// 商品类别信息
-(void)obtainMAProductInfoCateWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
- (void)shopCarAddProductWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
- (void)requestShopCarDataWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block;
@end
