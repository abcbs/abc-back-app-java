
//
//  MaOrderManager.m
//  G2TestDemo
//
//  Created by iOS  on 16/2/18.
//  Copyright © 2016年 ws. All rights reserved.
//

#import "MaOrderManager.h"
#import "NDLCoreBusincessHeader.h"
#import "JYModelConfigureHeader.h"
#import "HttpTool.h"
#import "B2bProduct.h"
#import "B2bProCategory.h"
#import "ZLH3CShopCarModel.h"
#import "B2bShoppingCart.h"
#define MeiYU @"http://192.168.1.117:8080"
@implementation MaOrderManager
+(MaOrderManager *) maOrderManager{
    static MaOrderManager *instance;
    if (!instance) {
        instance=[[super allocWithZone:nil]init];
    }
    return instance;
}

- (instancetype)init {
    if ((self = [super init]) != nil) {
        
        
    }
    return self;
}
//商品页面信息
-(void)obtainMaProductInfoWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block{
    
    NSLog(@"商品页面信息");
    NSString *urlStr = @"/b2b-main/iosProductB2b/b2bList";
    
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    
    [http postWithForm:urlStr parameters:queryDic modelClass:[B2bProduct class]
               keyPath:@"iosReturnJson/objectzJson" block:^(id responseObject, ErrorMessage *bsErrorMessage) {
                   NSLog(@"search :responseObject:%@",responseObject);
                   //服务器返回结构
                   if (bsErrorMessage) {
                       if (block) {
                           block(nil,bsErrorMessage);
                       }
                   }else {
                       
                       if (responseObject) {
                           if (block) {
                               block(responseObject,nil);
                           }
                       }
                   }
                   
                   
                   
               }];
    
}
// 商品类别信息
-(void)obtainMAProductInfoCateWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block{
      NSLog(@"商品类别信息");
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/proCategory/getProBycategoryGrade"];
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];

    [http postWithForm:urlStr parameters:queryDic modelClass:[B2bProCategory class]
               keyPath:@"iosReturnJson/objectzJson" block:^(id responseObject, ErrorMessage *bsErrorMessage) { NSLog(@"商品类别信息");
                   NSLog(@"%@",responseObject);
                   //服务器返回结构
                   NSMutableArray *cateAll = [NSMutableArray array];
                   //添加全部对象
                   B2bProCategory *modelAll = [[B2bProCategory alloc]init];
                   modelAll.categoryId = @"0";
                   modelAll.categoryName = @"全部";
                   [cateAll addObject:modelAll];
                   if (bsErrorMessage ) {
                       
                       if (bsErrorMessage.message.length > 0) {
                           UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提醒" message:bsErrorMessage.message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                           [alertView show];
                           return ;
                       }
                       
                   }else{
                       
                       [cateAll addObjectsFromArray:responseObject];
                       if (block) {
                           block(cateAll,nil);
                       }
                   }
                   
                   
               }];
    
    
}
//	http://192.168.1.227:8080/b2b-main/b2bShoppingCart/addB2bCartInfo
- (void)shopCarAddProductWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block {
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/b2bShoppingCart/addB2bCartInfo"];
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:NO];
    [http postWithFormCustomedError:urlStr parameters:queryDic modelClass:nil keyPath:@"iosReturnJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        //服务器返回结构
        NSLog(@"服务器返回结构response : %@",response);
        
        NSString *statusCode = response[@"iosReturnJson"][@"statusCode"];
        
        if ([statusCode isEqualToString:@"0000"]) {
            
            block(response , nil);
        }else if([statusCode isEqualToString:@"1000"]){
            
            NSLog(@"bsErrorMessage:%@",bsErrorMessage);
            //            NSString *message = bsErrorMessage.message;
            if(bsErrorMessage.message.length > 0){
                
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提醒" message:bsErrorMessage.message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                [alertView show];
                return ;
            }
            
        }
        
    }];
    
    
}
- (void)requestShopCarDataWithDic:(NSDictionary*)queryDic block:(NDlHttpResponse)block {
    NSString *urlStr = [NSString stringWithFormat:@"/b2b-main/b2bShoppingCart/getCart"];
    HttpTool * http=[HttpTool httpWithURL:NDL_JY_URL isErrorTemplate:YES];
    [http postWithFormCustomedError:urlStr parameters:queryDic modelClass:[B2bShoppingCart class] keyPath:@"iosReturnJson" block:^(id response, ErrorMessage *bsErrorMessage) {
        //iosReturnJson
        
        
        if (bsErrorMessage) {
            if (bsErrorMessage.message.length > 0) {
                UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"提醒" message:bsErrorMessage.message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                [alertView show];
                return ;
                
            }
            
            
        }
        if (response) {
            if (block) {
                block(response,nil);
                
            }
        }

    }];
    
}

@end
