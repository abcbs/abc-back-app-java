// JavaScript Document
$(function(){
	$(".metismenu>li:not('.nav-header')>a").click(function(){
		if(!$(this).parent("li").hasClass("active")){
			$(this).parent("li").addClass("active");
			$(this).parent("li").siblings("li").removeClass("active");
			$(this).parent("li").find("ul.nav-second-level").addClass("in");
			$(this).parent("li").siblings("li").find("ul.nav-second-level").addClass("collapse").removeClass("in");
		}else{
			$(this).parent("li").removeClass("active");
			$(this).parent("li").find("ul.nav-second-level").removeClass("in").addClass("collapse");
		}
	});
	$(".minimalize-styl-2").click(function(){
		if(!$("body").hasClass("body-small")){
			if(!$("body").hasClass("mini-navbar")){
				$("body").addClass("mini-navbar");
			}else{
				$("body").removeClass("mini-navbar");
				$(".metismenu").css({"opacity":opc});
				setTimeout(Opca,150);
			}
		}else{
			if($(".navbar-static-side").is(":hidden")){
				$("body").addClass("mini-navbar");
			}else{
				$("body").removeClass("mini-navbar");
			}
		}
	});
});
var opc=0;
function Opca(){
	var t=setInterval(function(){
		if(opc<1){
			opc=opc+0.05;
			$(".metismenu").css({"opacity":opc});
		}else{
			clearInterval(t);	
			opc=0;
		}
	},30);
	
}