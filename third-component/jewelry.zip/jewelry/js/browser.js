// JavaScript Document
$(function(){
	if($(window).width()<769){
		$("body").removeClass("body-small");
	}else{
		$("body").removeClass("body-small");
	}
	$(window).resize(function(e) {
        if($(window).width()<769){
			$("body").addClass("body-small");
		}else{
			$("body").removeClass("body-small");
		}
    });
});