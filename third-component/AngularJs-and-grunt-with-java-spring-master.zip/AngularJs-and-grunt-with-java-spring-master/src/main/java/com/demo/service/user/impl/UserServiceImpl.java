package com.demo.service.user.impl;

import org.springframework.stereotype.Component;

import com.demo.service.user.UserService;

/**
 * Service Class to implement method regarding user
 * 
 * @author admin
 *
 */
@Component
public class UserServiceImpl implements UserService {

}
