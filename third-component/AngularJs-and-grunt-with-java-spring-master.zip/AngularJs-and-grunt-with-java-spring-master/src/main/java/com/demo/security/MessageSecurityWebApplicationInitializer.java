package com.demo.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class MessageSecurityWebApplicationInitializer extends
		AbstractSecurityWebApplicationInitializer {

}
