package com.demo.service.user;

/**
 * Service Class to decalre method regarding user
 * 
 * @author admin
 *
 */
public interface UserService {

}
