package com.demo.config;

public class Constant {

}
