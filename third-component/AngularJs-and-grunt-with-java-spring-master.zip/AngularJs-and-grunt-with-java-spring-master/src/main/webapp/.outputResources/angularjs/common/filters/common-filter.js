'use strict';
var commonFilters = angular.module('common-filters');