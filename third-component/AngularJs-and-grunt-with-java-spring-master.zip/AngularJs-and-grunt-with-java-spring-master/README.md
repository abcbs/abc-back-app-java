# java-spring-demo

This is demo app created by  <a  href="http://iotasol.com/">Iotasol Pvt Ltd</a>

<h3>Technology Used</h3>

<ui>
    <li><a  href="http://www.oracle.com/technetwork/java/javase/overview/java8-2100321.html">Java JDK 1.8</a></li>
    <br>
    <li><a  href="#">Spring 4.1.0.RELEASE</a></li>
    <br>
    <li><a  href="#">Maven Project</a></li>
    <br>
    <li><a  href="#">Spring Security 3.2.5.RELEASE</a></li>
    <br>
    <li><a  href="#">Jpa 1.7.0.RELEASE</a></li>
    <br>
    <li><a  href="#">My Sql</a></li>
    <br>
    <li><a  href="#">Log4j2</a></li>
    <br>
    <li><a  href="#">jQuery</a></li>
    <br>
    <li><a  href="#">Bootstrap 3.3.2</a></li>
    <br>
    <li><a  href="#">Angular Js 1.3.8</a></li>
    <br>
    <li><a  href="#">Font Awesome 4.2.0 </a></li>
    <br>
    <li><a  href="#">Grunt</a></li>
    <br>
    <li><a  href="#">Bower Components</a></li>
    
</ui>

This is demp app which created using maven,Spring mvc with annotation based project and grunt.

Thanks,
<br>
<a  href="http://iotasol.com/">Iotasol Pvt Ltd</a>
