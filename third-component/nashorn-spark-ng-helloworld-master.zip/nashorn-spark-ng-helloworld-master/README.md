nashorn-spark-ng-helloworld
===========================

Fun with Nashorn (JDK8), Spark-java and AngularJS.

A small a proof of concept, running a simple web server with latest JS engine from JDK8 (Nashorn).

How to run it? Install JDK8, ant & ivy from ant.apache.org and just run 'ant'
