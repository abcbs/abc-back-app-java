## Day 22 Demo Application##

To run it on OpenShift, execute the following command.

```
$ rhc create-app getbookmarks tomcat-7 mongodb-2 --from-code https://github.com/shekhargulati/day22-spring-angularjs-demo-app.git
```