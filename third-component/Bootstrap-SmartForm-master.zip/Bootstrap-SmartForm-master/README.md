# Bootstrap-Form-plugin
背景：本码农.NET后端工程师，在项目开发中发现写了很多重复的代码，于是自己整了一套根据配置来生成form表单的插件，针对表单的改动仅需要修改配置的json即可，实用中发现还是蛮实用的，于是开源出来贡献与广大博友，技术含量不算高，就一个小插件，代码量不多但是短小精悍比较实用，大神勿喷~~~
系列教程：http://www.cnblogs.com/xiexingen/p/4553354.html

本系列将包括

1、<a href="http://www.cnblogs.com/xiexingen/p/4555416.html" target="_blank">BootStrap智能表单系列 一 Demo示例</a>

2、<a href="http://www.cnblogs.com/xiexingen/p/4555527.html" target="_blank">BootStrap 智能表单系列 二 BootStrap支持的类型简介</a>

3、<a href="http://www.cnblogs.com/xiexingen/p/4556012.html" target="_blank">BootStrap 智能表单系列 三 分块表单配置的介绍</a>

4、<a href="http://www.cnblogs.com/xiexingen/p/4556014.html" target="_blank">BootStrap 智能表单系列 四  表单布局介绍</a>

5、<a href="http://www.cnblogs.com/xiexingen/p/4556016.html" target="_blank">BootStrap 智能表单系列 五  表单依赖插件处理</a>

6、<a href="http://www.cnblogs.com/xiexingen/p/4556059.html" target="_blank">BootStrap 智能表单系列 六 表单数据绑定(编辑页面的数据绑定)</a>

7、<a href="http://www.cnblogs.com/xiexingen/p/4556017.html" target="_blank">BootStrap 智能表单系列 七 验证的支持</a>

8、<a href="http://www.cnblogs.com/xiexingen/p/4556020.html" target="_blank">BootStrap 智能表单系列 八 表单配置json详解</a>

9、<a href="http://www.cnblogs.com/xiexingen/p/4590384.html" target="_blank">BootStrap 智能表单系列 九 表单图片上传的支持</a>

10、<a href="http://www.cnblogs.com/xiexingen/p/4590397.html" target="_blank">BootStrap 智能表单系列 十 自动完成组件的支持</a>

11、<a href="http://www.cnblogs.com/xiexingen/p/4590404.html" target="_blank">BootStrap 智能表单系列 十一 级联下拉的支持</a>
