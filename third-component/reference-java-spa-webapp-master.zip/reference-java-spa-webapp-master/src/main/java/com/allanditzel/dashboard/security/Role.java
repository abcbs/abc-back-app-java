package com.allanditzel.dashboard.security;

/**
 * Created by Allan on 6/8/2014.
 */
public enum Role {
    USER,
    ADMINISTRATOR;
}
