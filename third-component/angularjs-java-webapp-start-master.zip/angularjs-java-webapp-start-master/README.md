angularjs-java-webapp-start
===========================

A java war project for eclipse with maven, java and angularjs. The project will be set up so it can be imported as an existing eclipse project and have angular, the servlets and rest service already setup.
