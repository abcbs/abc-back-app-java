package com.camriley.util;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;
import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ManifestUtilBeanTest {

	ManifestUtilBean bean;
	
	@Before
	public void setUp() {
		bean = new ManifestUtilBean();
	}

	@After
	public void tearDown() {
		bean = null;
	}
	
	@Test
	public void shouldSetUp() {
		bean.setUp();
	}
	
	@Test
	public void shouldGetManifest() throws Exception {
		
		ServletContext context = mock(ServletContext.class);
		when(context.getResourceAsStream(any(String.class))).thenReturn(IOUtils.toInputStream(""));
		
		Map<String, String> result = bean.getManifest(context);
		assertEquals(result.size(), 0, 0);
	}
	
	
}
