package com.camriley.util;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;


/**
 * Simple util for injecting mock objects via reflection
 * into member variables
 * @author cam
 */
public class Injector {

	/**
	 * Inject a mock into the member variable (identified by class type) into the bean
	 * @param bean the object with the member variables to be injected
	 * @param clazz the type of the mock object being injected
	 * @param mock the reference to the mock itself of type clazz
	 * @throws Exception because something goes wrong with reflection
	 */
	public static <T,E> void set(T bean, Class<?> clazz, E mock) throws Exception {
		for (Field field : bean.getClass().getDeclaredFields()) {
			if (field.getType().getName().equals(clazz.getName())) {
				
				/**
				 * make member variable public
				 */
				field.setAccessible(true); 
				
				/**
				 * for handling private static final member variables.
				 */
				Field modifiersField = Field.class.getDeclaredField("modifiers");
				modifiersField.setAccessible(true);
				modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
				
				/**
				 * inject
				 */
				field.set(bean, mock);
				
				/**
				 * make private again
				 */
				field.setAccessible(false);
			}
		}
	}

}
