package com.camriley.service;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.camriley.dto.ManifestResponseDTO;
import com.camriley.dto.Status;
import com.camriley.util.Injector;
import com.camriley.util.ManifestUtilBean;

public class ManifestServiceTest {

	ManifestService bean;
	ServletContext context = mock(ServletContext.class);
	ManifestUtilBean manifestUtilBean = mock(ManifestUtilBean.class);
	
	@Before
	public void setUp() throws Exception {
		bean = new ManifestService();
		Injector.set(bean, ServletContext.class, context);
		Injector.set(bean, ManifestUtilBean.class, manifestUtilBean);
	}

	@After
	public void tearDown() {
		bean = null;
	}
	
	@Test
	public void shouldManifest() throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("KEY", "VALUE");
		
		when(manifestUtilBean.getManifest(any(ServletContext.class))).thenReturn(map);
		
		ManifestResponseDTO result = bean.manifest();
		assertEquals(Status.SUCCESS, result.status);
		assertEquals(1, result.manifest.size());
	}
}
