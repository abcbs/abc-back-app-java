"use strict";

describe("controllers", function(){

	it("should load as angular module", function() {
		expect(app).not.toBe(null);
		expect(app).toBeDefined();
	});
});