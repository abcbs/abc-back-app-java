"use strict";

describe("controllers", function(){
	
	var scope = null;
	var controller = null; 
	var $httpBackend = null;
	
	beforeEach(inject(function(_$httpBackend_, $rootScope, $controller) {
		$httpBackend = _$httpBackend_;
	      $httpBackend.expectGET('service/manifest/').respond({ 'status': 'SUCCESS', manifest : { 'KEY': 'VALUE'}});
	 
	      scope = $rootScope.$new();
	      ctrl = $controller('ManifestController', {$scope: scope});
	}));

	it("should get manifest from service", function() {
		
		expect(controller).not.toBe(null);
		expect(scope.result).not.toBe(null);
		expect(scope.result.status).toBe('SUCCESS');
		expect(scope.result.manifest.KEY).toBe('VALUE');
	});
});