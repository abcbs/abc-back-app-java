"use strict";

/**
 * The angular app name, this is injected into the html tag
 */
var app = angular.module("app", []);


app.config(['$routeProvider',
    function($routeProvider) {
		$routeProvider.when('/',{ templateUrl: 'partials/index.html'});
		$routeProvider.when('/login',{ templateUrl: 'partials/login.html', controller: 'loginController' }),
		$routeProvider.when('/signup',{ templateUrl: 'partials/signup.html', controller: 'loginController' }),
		$routeProvider.otherwise({ redirectTo: '/' });
    }
]);