"use strict";

/**
 * Angularjs controllers
 */
app.controller('manifestController', function($scope, $http) {
	
	$http.get('service/manifest/').success(function(data) {
		console.log(data);
		$scope.result = data;
	});	
});

/**
 * For login and signup buttons
 */
app.controller('loginController', function($scope, $http, $location) {
	
	$scope.signup=function() {
		console.log("sign in clicked!!");
		$location.path('/signup');
	};

	$scope.login=function() {
		console.log("login clicked!!");
		$location.path('/login');
	};
	
	$scope.isValidAccount=function() {
		console.log("isValidAccount clicked!!");
		var request = { email: $scope.login.email, password: $scope.login.password, rememberMe: $scope.login.rememberme };
		console.log(request);
		$http({ method: 'POST', url: 'service/account/login', data: request })
		.success(function(data, status, headers, config) {
			console.log("success!!");
			console.log(data);
			$location.path('/');
		})
		.error(function(data, status, headers, config) {
			console.log("fail!!");
			console.log(data);
			$location.path('/login');
		});
	};

});
