package com.camriley.dto.account;

/**
 * Request dto for login and creating accounts
 * @author cam
 */
public class AccountRequestDTO {

	/**
	 * Account email
	 */
	public String email;
	
	/**
	 * The password for an account
	 */
	public String password;
	
	/**
	 * Remember the account when they login
	 */
	public boolean rememberMe;
}
