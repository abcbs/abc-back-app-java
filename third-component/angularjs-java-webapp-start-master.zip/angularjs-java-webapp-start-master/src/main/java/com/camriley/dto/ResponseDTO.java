package com.camriley.dto;

/**
 * Parent class for all CXF responses
 * @author cam
 */
public class ResponseDTO {

	public Status status;

}
