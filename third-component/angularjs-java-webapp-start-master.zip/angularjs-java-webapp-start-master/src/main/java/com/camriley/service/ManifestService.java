package com.camriley.service;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;

import com.camriley.dto.ManifestResponseDTO;
import com.camriley.dto.Status;
import com.camriley.util.ManifestUtilBean;

/**
 * Rest service for exposing the Manifest information in the war file
 * @author cam
 */
@Path("/")
public class ManifestService {

	/**
	 * Servlet context for the request/response
	 */
	@Autowired
	ServletContext context;

	/**
	 * Spring bean for accessing the manifest information. 
	 * Specified in WEB-INF/applicationContext.xml
	 */
	@Autowired
	ManifestUtilBean manifestUtilBean;
	
	/**
	 * Get the manifest information that is in the MANIFEST.MF in the war file
	 * @return map of the manifest entries
	 * @throws Exception if something goes wrong
	 */
	@GET
	@Path("/")
	@Consumes({ MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public ManifestResponseDTO manifest() throws Exception {
		
		ManifestResponseDTO dto = new ManifestResponseDTO();
		dto.status = Status.SUCCESS;
		dto.manifest = manifestUtilBean.getManifest(context);
		
		return dto;
	}

	
}
