package com.camriley.util;

import java.util.HashMap;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Util for accessing the information in the WAR's manifest
 * @author cam
 */
public class ManifestUtilBean {

	Logger LOG = LoggerFactory.getLogger(ManifestUtilBean.class);

	@PostConstruct
	protected void setUp() {
		LOG.info("ManifestUtilBean post construct");
	}
	
	/**
	 * Get the manifest information from the MANIFEST.MF in the war file
	 * @param context the servlet context so that the manifest can be accessed inside the war
	 * @return map with the manifest name/value pairs
	 * @throws Exception if there is an error getting the manifest information
	 */
	public Map<String,String> getManifest(ServletContext context) throws Exception {
		
		Map<String,String> values = new HashMap<String,String>();
		
		Manifest manifest = new Manifest(context.getResourceAsStream("/META-INF/MANIFEST.MF"));
		Attributes attributes = manifest.getMainAttributes();
		
		for (Map.Entry<Object, Object> entry : attributes.entrySet()) {
			values.put(((Attributes.Name)entry.getKey()).toString(), (String)entry.getValue());
		}
		return values;
	}
}
