package com.camriley.servlet;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.camriley.util.ManifestUtilBean;
import com.camriley.util.ServletInjectionUtilBean;

/**
 * Entry servlet for the application
 */
@WebServlet("/index")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/**
	 * Injection util which allows us to inject spring beans into the servlet
	 */
	private ServletInjectionUtilBean injectionUtil = new ServletInjectionUtilBean();

	/**
	 * Spring bean declared in applicationContext.xml
	 */
	@Autowired
	ManifestUtilBean manifestBean;
	
	/**
	 * Init so we can add the util to inject spring beans into the servlet
	 */
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		injectionUtil.enableDependencyInjection(this, config.getServletContext());
	}
	
	/**
	 * Send the index servlet to the index.jsp page
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			Map<String,String> manifest = manifestBean.getManifest(getServletConfig().getServletContext());
			request.setAttribute("manifest", manifest);
		} catch (Exception e) {
			// do nothing
		}
		
		getServletConfig().getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
	}

}
