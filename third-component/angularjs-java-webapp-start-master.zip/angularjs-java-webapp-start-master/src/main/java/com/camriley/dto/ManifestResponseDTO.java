package com.camriley.dto;

import java.util.Map;

/**
 * Manifest response data transfer object
 * @author cam
 */
public class ManifestResponseDTO extends ResponseDTO {

	public Map<String,String> manifest;
	
}
