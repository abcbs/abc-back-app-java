package com.camriley.dto;

/**
 * Response status
 * @author cam
 */
public enum Status {
	
	SUCCESS,
	FAIL,
	ERROR;
}
