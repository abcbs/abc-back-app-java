package com.camriley.util;

import javax.servlet.ServletContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

public class ServletInjectionUtilBean {
	
	public void enableDependencyInjection(Object target, ServletContext context) {
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(target, context);
	}
}
