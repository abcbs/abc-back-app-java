package com.camriley.integration;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.camriley.util.AccountUtil;

/**
 * Integration bean for the accounts
 * @author cam
 */
public class AccountIntegrationBean {

	/**
	 * Is the username and password valid
	 * @param username the email of the account
	 * @param password the password of the account
	 * @return true if the account username/password is valid
	 */
	public boolean isValidAccount(String username, String password, HttpServletRequest request, HttpServletResponse response) {
		
		setCookie(request, response);
		return true;
	}
	
	/**
	 * Set the cookie on the servlet response, this will update the cookie
	 * if it already exists
	 * @param response the http servlet response
	 */
	public void setCookie(HttpServletRequest request, HttpServletResponse response) {
		
		Cookie cookie = null;
		Cookie cookies[] = request.getCookies();
		for (Cookie existingCookie : cookies) {
			if (existingCookie.getName().equalsIgnoreCase("rememberme")) {
				cookie = existingCookie;
			}
		}
		
		if (cookie==null) {
			cookie = new Cookie("rememberme", AccountUtil.getUUID());
		}
		cookie.setMaxAge(60*60*24*7);
		response.addCookie(cookie);
	}
	
}
