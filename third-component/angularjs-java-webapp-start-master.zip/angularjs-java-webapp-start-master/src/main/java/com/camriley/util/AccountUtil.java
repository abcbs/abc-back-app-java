package com.camriley.util;

import java.util.UUID;

/**
 * Utility class for the account operations
 * @author cam
 */
public class AccountUtil {
	
	/**
	 * Create a new UUID
	 * @return the uuid as a string
	 */
	public static String getUUID() {
		return UUID.randomUUID().toString();
	}
	
}
