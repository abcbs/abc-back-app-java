package com.camriley.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.camriley.dto.ResponseDTO;
import com.camriley.dto.Status;
import com.camriley.dto.account.AccountRequestDTO;
import com.camriley.integration.AccountIntegrationBean;

/**
 * Service for interacting with accounts
 * @author cam
 */
@Path("/")
public class AccountService {
	
	Logger LOG = LoggerFactory.getLogger(AccountService.class);
	
	/**
	 * Spring bean for integrating with accounts
	 */
	@Autowired
	private AccountIntegrationBean accountIntegrationBean;
	
	/**
	 * Login an account
	 * @param requestDTO the request with the username and password
	 * @return response of success or fail
	 */
	@POST
	@Path("/login")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public ResponseDTO login(final AccountRequestDTO requestDTO, final HttpServletRequest request, final HttpServletResponse response) {
		
		ResponseDTO dto = new ResponseDTO();
		
		if (accountIntegrationBean.isValidAccount(requestDTO.email, requestDTO.password, request, response)) {
			dto.status = Status.SUCCESS;
		} else {
			dto.status = Status.FAIL;
		}
		
		return dto;
	}
}
