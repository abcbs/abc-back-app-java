#!/bin/sh

PID=$(ps aux | grep tomcat | grep -v grep | awk '{print $2}')
if [[ ! -z "${PID}" ]]
then
	ps aux | grep tomcat | grep -v grep | awk '{print $2}' | xargs kill -9
fi


mvn clean install -U 
mvn tomcat7:run 

exit 0