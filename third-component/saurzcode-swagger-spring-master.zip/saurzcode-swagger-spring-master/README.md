saurzcode-swagger-spring
========================

Project to Demo Swagger Configuration for a Spring MVC project using Spring Boot for blog.

http://saurzcode.in/2014/08/19/how-to-configure-swagger-to-generate-restful-api-doc-for-your-spring-boot-web-application/
