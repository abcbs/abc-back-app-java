/**
 * Contains Emergya's Java utilities.
 */
package com.emergya.java;
