/**
 * Tag handler clases for building AngularJS automatically.
 */
package com.emergya.java.tags.angular;
