package com.emergya.java.tags.angular.annotations;

/**
 *
 * @author lroman
 */
public enum FilterFieldOp {
    EQUALS,
    LIKE,
    GREATER,
    LOWER,
    GR_EQ,
    LO_EQ
}
