/**
 * Contains annotations used to provide information about fields.
 */
package com.emergya.java.tags.angular.annotations;
