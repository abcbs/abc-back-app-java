package <%=packageName%>.domain.enumeration;

/**
 * The <%= enumName %> enumeration.
 */
public enum <%= enumName %> {
    <%= enumValues %>
}
