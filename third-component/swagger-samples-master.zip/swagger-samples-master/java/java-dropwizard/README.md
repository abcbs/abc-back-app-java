To run the sample:

```
mvn package

java -jar target/swagger-java-dropwizard-sample-app-1.0.0.jar server conf/swagger-sample.yml 

```

You can then access swagger at http://localhost:8080/swagger.json
